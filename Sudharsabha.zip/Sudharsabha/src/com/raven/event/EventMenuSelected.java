package com.raven.event;

public interface EventMenuSelected {

    public void menuSelected(int menuIndex, int subMenuIndex);
}
